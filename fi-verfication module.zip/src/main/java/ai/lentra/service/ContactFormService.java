package ai.lentra.service;

import ai.lentra.dto.ResponseDTO;
import ai.lentra.exceptions.ResourceNotFoundException;
import ai.lentra.modal.ContactForm;
import ai.lentra.modal.lookups.SimCardType;
import ai.lentra.repository.ContactFormRepository;
import ai.lentra.repository.lookups.SimCardTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ContactFormService {
    @Autowired
    ContactFormRepository repository;
    @Autowired
    SimCardTypeRepository simCardTypeRepository;

    public ResponseEntity<?> getByApplicantId(Long applicantId) {
        ContactForm contactForm = repository.findByApplicantId(applicantId);
        return (contactForm == null ? ResponseEntity.status(HttpStatus.NOT_FOUND).body("Details Not Found for the particular Applicant Id : " + applicantId) : ResponseEntity.status(HttpStatus.OK).body(contactForm));
    }


    public ResponseEntity<?> save(ContactForm contactForm, Long applicantId) throws ResourceNotFoundException {
        // Check if the sim card type exists in the database
        SimCardType simType = simCardTypeRepository.findByTypeIgnoreCase(contactForm.getSimType().getType());
        if (simType == null) {
            throw new ResourceNotFoundException("Sim card type : "+contactForm.getSimType().getType()+" not found ");
        }
        contactForm.setApplicantId(applicantId);
        contactForm.setSimType(simType);

        ContactForm newContactForm = repository.save(contactForm);

//        return ResponseEntity.created(URI.create("/contact-forms/" + newContactForm.getApplicantId())).body(newContactForm);
        ResponseDTO responseDTO=new ResponseDTO();
        responseDTO.setCode(HttpStatus.CREATED);
        responseDTO.setMessage("Contact Information Created   Successfully");
        responseDTO.setStatus("Created");
        return (repository.save(contactForm) == null ? ResponseEntity.status(HttpStatus.NOT_FOUND).body("Details Not Found") : ResponseEntity.status(HttpStatus.CREATED).body(responseDTO));
    }

    public ResponseEntity<?> updateContcatDetails(ContactForm contactForm, Long applicantId) {
        Optional<ContactForm> optionalApplicant = Optional.ofNullable(repository.findByApplicantId(applicantId));
        if (!optionalApplicant.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        ContactForm existingContact = optionalApplicant.get();
        if (contactForm.getMobileNumber().equals(null)) {
            existingContact.setMobileNumber(contactForm.getMobileNumber());
        }
        if (contactForm.getPersonalEmail() != null) {
            existingContact.setPersonalEmail(contactForm.getPersonalEmail());
        }
        if (contactForm.getSimType() != null) {
            SimCardType simType = simCardTypeRepository.findByTypeIgnoreCase(contactForm.getSimType().getType());
            existingContact.setSimType(simType);
        }

        if (contactForm.isMobileNumberVerified() != existingContact.isMobileNumberVerified()) {
            existingContact.setMobileNumberVerified(contactForm.isMobileNumberVerified());
        }
        if (contactForm.getPhoneNumber() != null) {
            existingContact.setPhoneNumber(contactForm.getPhoneNumber());
        }
        if (contactForm.isPhoneNumberVerified() != existingContact.isPhoneNumberVerified()) {
            existingContact.setPhoneNumberVerified(contactForm.isPhoneNumberVerified());
        }
        if (contactForm.isPersonalEmailVerified() != existingContact.isPersonalEmailVerified()) {
            existingContact.setPersonalEmailVerified(contactForm.isPersonalEmailVerified());
        }
        if (contactForm.isDomainCheck() != existingContact.isDomainCheck()) {
            existingContact.setDomainCheck(contactForm.isDomainCheck());
        }
        if (contactForm.isRegisteredWithBank() != existingContact.isRegisteredWithBank()) {
            existingContact.setRegisteredWithBank(contactForm.isRegisteredWithBank());
        }
//Success Response
        ResponseDTO successResponseDTO=new ResponseDTO();
        successResponseDTO.setCode(HttpStatus.CREATED);
        successResponseDTO.setMessage("Contact Information Created   Successfully");
        successResponseDTO.setStatus("Created");
        //Error Response
        ResponseDTO errResponseDTO = new ResponseDTO();
        errResponseDTO.setCode(HttpStatus.NOT_FOUND);
        errResponseDTO.setMessage("Contact Information Not Updated");
        errResponseDTO.setStatus("Failed to Update");
        return (repository.save(existingContact) == null ? ResponseEntity.status(HttpStatus.NOT_FOUND).body(errResponseDTO) : ResponseEntity.status(HttpStatus.OK).body(successResponseDTO));




    }

}