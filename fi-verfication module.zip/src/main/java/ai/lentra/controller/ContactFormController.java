package ai.lentra.controller;

import ai.lentra.exceptions.ResourceNotFoundException;
import ai.lentra.modal.ContactForm;
import ai.lentra.service.ContactFormService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.*;
import java.util.Set;

@RestController
@Validated
@RequestMapping(value = "/contact-forms")
public class ContactFormController {

@Autowired
    ContactFormService contactFormService;

    @PostMapping("/{applicantId}")
    public ResponseEntity<?> createUser(@RequestBody @Valid ContactForm contactForm, @PathVariable Long applicantId) throws ResourceNotFoundException {

    return contactFormService.save(contactForm,applicantId);
    }
    @GetMapping("/{applicantId}")
    public ResponseEntity<?> getForm(@PathVariable Long applicantId) throws ResourceNotFoundException {
        return contactFormService.getByApplicantId(applicantId);
    }
   @PatchMapping("/update-form/{applicantId}")
    public ResponseEntity<?> updateForm(@Valid @RequestBody ContactForm contactForm, @PathVariable Long applicantId) throws ResourceNotFoundException {
        return contactFormService.updateContcatDetails(contactForm,applicantId);
    }


}
