package ai.lentra.modal;

import ai.lentra.modal.lookups.SimCardType;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Data
public class ContactForm {

    @Id
    @Column(name = "applicant_id", nullable = false)
    private long applicantId;
    @NotNull(message = "Mobile number should not be null")
    @Pattern(regexp = "^\\d{10,13}$",message = "Mobile number should contain 10 to 13 digits only")
    private String mobileNumber;

    @Email
    private String personalEmail;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "sim_card_type_id")
    private SimCardType simType;

    private boolean mobileNumberVerified;

    @Pattern(regexp = "^\\d{10,13}$",message = "Phone number should contain 10 to 13 digits only")
    private String phoneNumber;

    private boolean phoneNumberVerified;
    private boolean personalEmailVerified;
    private boolean domainCheck;
    private boolean registeredWithBank;

    // constructors, getters, setters, etc.
}
