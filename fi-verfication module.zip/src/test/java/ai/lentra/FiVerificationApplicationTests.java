package ai.lentra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiVerificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
